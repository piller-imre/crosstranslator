package expressions;
public abstract class Expression {

	
}
