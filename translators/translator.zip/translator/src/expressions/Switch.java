package expressions;

public class Switch extends Expression {

}
