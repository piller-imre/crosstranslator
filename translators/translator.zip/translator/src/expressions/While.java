package expressions;

public class While extends Expression {

}
