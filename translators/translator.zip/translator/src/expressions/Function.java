package expressions;

public class Function extends Expression {

}
