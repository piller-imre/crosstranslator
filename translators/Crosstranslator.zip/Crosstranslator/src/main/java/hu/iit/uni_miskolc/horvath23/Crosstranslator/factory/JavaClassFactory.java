package hu.iit.uni_miskolc.horvath23.Crosstranslator.factory;

public class JavaClassFactory extends AbstractFactory {

	@Override
	public JavaClass createCass() {
		JavaClass newClass = new JavaClass();
		return newClass;
	}

}
