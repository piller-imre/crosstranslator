package hu.iit.uni_miskolc.horvath23.Crosstranslator.factory;

public interface ClassCreator {

}
