package hu.iit.uni_miskolc.horvath23.Crosstranslator.expressions;
public abstract class Expression {

	
}
