package hu.iit.uni_miskolc.horvath23.Crosstranslator.factory;

public abstract class AbstractFactory {
	private static final JavaClassFactory JAVA_CLASS = new JavaClassFactory();
	
	static AbstractFactory getFactory(Languages language) {
		AbstractFactory factory = null;
		switch (language) {
			case JAVA:
				factory = JAVA_CLASS;
				break;
		}
		return factory;
	}
	
	public abstract ClassCreator createCass();
}
