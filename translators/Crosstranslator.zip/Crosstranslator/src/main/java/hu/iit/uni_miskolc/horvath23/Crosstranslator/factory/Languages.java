package hu.iit.uni_miskolc.horvath23.Crosstranslator.factory;

public enum Languages {
	JAVA
}
