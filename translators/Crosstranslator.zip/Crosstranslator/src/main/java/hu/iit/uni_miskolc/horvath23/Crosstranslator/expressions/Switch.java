package hu.iit.uni_miskolc.horvath23.Crosstranslator.expressions;

public class Switch extends Expression {

}
